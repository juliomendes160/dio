# ApiCatalogoJogos
Este projeto foi desenvolvido para exemplificar a estrutura de uma API Rest. Ela será utilizada para auxiliar a live que apresentarei na DIO.
