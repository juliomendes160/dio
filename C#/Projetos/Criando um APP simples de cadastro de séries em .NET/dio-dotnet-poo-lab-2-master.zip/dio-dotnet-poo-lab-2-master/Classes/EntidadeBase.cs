namespace DIO.Series
{
    public abstract class EntidadeBase
    {
        public int Id { get; protected set; }

    }
}